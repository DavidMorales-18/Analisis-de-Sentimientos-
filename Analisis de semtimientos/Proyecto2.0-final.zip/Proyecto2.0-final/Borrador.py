import Proyecto as p1

p1.consulta('amor')


print(p1.curacion[0])
print(p1.result[0])
print(p1.result[1])
print(len(p1.result[0]))
